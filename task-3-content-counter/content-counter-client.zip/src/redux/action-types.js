// 请求成功时分发
export const REQUEST_SUCCESS = 'request_success' ;
// 请求失败时分发
export const REQUEST_FAILURE = 'request_failure' ;
// 发起请求时分发，表示请求刚刚发起
export const INIT_REQUEST = 'init_request' ;